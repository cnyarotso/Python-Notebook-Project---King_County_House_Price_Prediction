# King County House Price Prediction

## Project Overview
This project analyzes and predicts residential house prices for King County, Washington, using Python data analysis and regression modeling techniques. The scenario is framed as work for a Real Estate Investment Trust (REIT) evaluating residential real estate investment opportunities.

The project uses house sales data from King County, including Seattle, with home sales between May 2014 and May 2015. The target variable is `price`, and the analysis explores housing features such as square footage, bedrooms, bathrooms, floors, waterfront view, grade, and location.

## Repository Contents

- `King_County_House_Price_Prediction.ipynb` — Completed Jupyter notebook with analysis and model outputs.
- `kc_house_data.csv` — Housing dataset used for analysis.
- `Project_Screenshots.pdf` — Screenshots of final outputs for Questions 1–10.
- `requirements.txt` — Python libraries used in the project.
- `.gitignore` — Standard Python/Jupyter ignore file.

## Key Questions Completed

1. Displayed data types for each column using `df.dtypes`.
2. Dropped unnecessary columns and generated descriptive statistics.
3. Counted unique floor values using `value_counts().to_frame()`.
4. Used seaborn boxplot to compare price outliers by waterfront status.
5. Used seaborn regplot to examine the relationship between `sqft_above` and `price`.
6. Built a simple linear regression model using `sqft_living` to predict `price`.
7. Built a multiple linear regression model using selected housing features.
8. Created a scikit-learn pipeline using scaling, polynomial transformation, and linear regression.
9. Created and evaluated a Ridge regression model with `alpha=0.1`.
10. Applied a second-order polynomial transformation and Ridge regression, then evaluated R² on test data.

## Methods Used

- Data loading and inspection
- Missing value handling
- Descriptive statistics
- Exploratory data analysis
- Boxplots and regression plots
- Simple linear regression
- Multiple linear regression
- Polynomial feature transformation
- Pipeline modeling
- Ridge regression
- Model evaluation using R²

## Main Tools and Libraries

- Python
- pandas
- NumPy
- seaborn
- matplotlib
- scikit-learn
- Jupyter Notebook

## Project Highlights

- `sqft_living` explains approximately 49% of the variation in house prices in the simple linear regression model.
- The multiple linear regression model improves performance, with an R² around the 0.60–0.70 range.
- Waterfront houses tend to have higher median prices than non-waterfront houses.
- `sqft_above` shows a positive relationship with price.
- Ridge regression and polynomial features were used to improve model flexibility while managing overfitting.

## How to Run

1. Clone or download this repository.
2. Open `King_County_House_Price_Prediction.ipynb` in Jupyter Notebook, JupyterLab, VS Code, or Google Colab.
3. Ensure the dataset `kc_house_data.csv` is in the same folder as the notebook.
4. Run the notebook cells from top to bottom.

## Suggested GitHub Repository Name

`king-county-house-price-prediction`
